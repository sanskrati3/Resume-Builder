const resumeDB = [];

module.exports = { resumeDB };
